
           ******* ERUNTgui version 1.5.0 ********
               Windows NT/2000/2003/XP/Vista/7 
   
              Copyright 2009,2012  Klaus Roemer  
                    All Rights reserved

                  
                     Original "ERUNT"
                Copyright 2005 Lars Hederer

                   

 "ERUNTgui" is a graphic user interface for the popular
 registry backup and restore program "ERUNT" created by Lars Hederer.

 My reason for creating "ERUNTgui", is to place all the modules
 that make up the original "ERUNT" utility in to one user interface,
 making the program easier to use.

 To find out more, go to the "Help File".
  K.R.


Important notes from Lars Hederer (Autor of original "ERUNT")
----------------------------------------------------------------
Question: Do ERUNT and NTREGOPT run on Windows 7? Answer: ERUNT and NTREGOPT in their current versions 1.1j are still compatible with Windows 7, but as in Vista, they will only work correctly if you turn off User Account Control in Windows' Control Panel (move the slider to the lowest position). 
Also, a problem has been discovered which on many systems causes ERDNT and NTREGOPT to display a "RegSaveKey: 3" error when optimizing / restoring the BCD00000000 hive. The cause is that after a clean install of Windows 7, the BCD part of the registry which contains Windows' boot configuration data resides on a hidden system partition with no drive letter assigned in Explorer. You can simply ignore this error and continue, or as a workaround, open Disk Managemant in Control Panel and right-click on the partition displayed as "System Reserved" to assign a drive letter. 
Future versions of ERUNT and NTREGOPT will of course have these issues fixed. Keep an eye on my homepage for updates.
